const S={g(k,d){try{const v=localStorage.getItem('enx_'+k);return v?JSON.parse(v):d}catch(e){return d}},
s(k,v){try{localStorage.setItem('enx_'+k,JSON.stringify(v))}catch(e){alert('Storage full. Delete some products or use smaller images.')}}};
const DEF={bkash:'01XXXXXXXXX',nagad:'01XXXXXXXXX',wa:'',pass:'admin123',ship:60};
const cfg=()=>({...DEF,...S.g('cfg',{})});
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const tk=n=>'৳'+Number(n).toLocaleString('en-US');
const $=id=>document.getElementById(id);
if(!S.g('prods'))S.s('prods',[
{id:1,name:'Wireless Earbuds Pro',cat:'Audio',price:1850,stock:25,img:''},
{id:2,name:'Smart Watch Series 5',cat:'Wearables',price:3200,stock:12,img:''},
{id:3,name:'Gaming Controller',cat:'Gaming',price:2400,stock:8,img:''},
{id:4,name:'20000mAh Power Bank',cat:'Accessories',price:1650,stock:30,img:''}]);

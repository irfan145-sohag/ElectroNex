ElectroNex – deploy on GitHub Pages
1. Create a GitHub repo, upload all files from this ZIP (unzipped) to the repo root.
2. Settings > Pages > Deploy from branch > main / root > Save.
3. Shop: your-site/   Admin: your-site/admin.html  (default password: admin123 - change it in Settings)
